using System;
using UnityEngine;

namespace ItemSystem.Core
{
    /// <summary>
    /// Bir eşyanın runtime durumunu tutar.
    /// Definition değişmez, Instance değişebilir (adet, dayanıklılık vb.)
    /// </summary>
    [Serializable]
    public class ItemInstance
    {
        // ── Tanımlayıcı ──────────────────────────────────────────
        public readonly string instanceId;
        public ItemDefinition Definition { get; private set; }

        // ── Yığın ────────────────────────────────────────────────
        public int Amount { get; private set; }

        // ── Dayanıklılık (opsiyonel) ─────────────────────────────
        public float Durability { get; private set; }
        public float MaxDurability { get; private set; }
        public bool HasDurability => MaxDurability > 0f;

        // ── Silah özel state ─────────────────────────────────────
        public int CurrentAmmo { get; private set; }

        // ─────────────────────────────────────────────────────────

        public ItemInstance(ItemDefinition definition, int amount = 1, float maxDurability = 0f)
        {
            instanceId  = Guid.NewGuid().ToString();
            Definition  = definition;
            Amount      = Mathf.Clamp(amount, 1, definition.maxStack);
            MaxDurability = maxDurability;
            Durability  = maxDurability;

            if (definition.weaponData != null)
                CurrentAmmo = definition.weaponData.magazineSize;
        }

        // ── Yığın işlemleri ──────────────────────────────────────

        public void SetAmount(int amount)
            => Amount = Mathf.Clamp(amount, 0, Definition.maxStack);

        public void AddAmount(int delta)
            => SetAmount(Amount + delta);

        public bool IsEmpty => Amount <= 0;

        // ── Dayanıklılık ─────────────────────────────────────────

        public void ApplyDurabilityDamage(float damage)
        {
            if (!HasDurability) return;
            Durability = Mathf.Max(0f, Durability - damage);
        }

        public bool IsBroken => HasDurability && Durability <= 0f;

        // ── Mermi ────────────────────────────────────────────────

        public bool HasAmmo => CurrentAmmo > 0;

        public void SpendAmmo(int count = 1)
        {
            CurrentAmmo = Mathf.Max(0, CurrentAmmo - count);
        }

        public void Reload()
        {
            if (Definition.weaponData == null) return;
            CurrentAmmo = Definition.weaponData.magazineSize;
        }

        // ── Klonlama ─────────────────────────────────────────────

        public ItemInstance Clone(int overrideAmount = -1)
        {
            int amt = overrideAmount < 0 ? Amount : overrideAmount;
            var clone = new ItemInstance(Definition, amt, MaxDurability);
            clone.Durability   = Durability;
            clone.CurrentAmmo  = CurrentAmmo;
            return clone;
        }

        public override string ToString()
            => $"[ItemInstance] {Definition.displayName} x{Amount} (ID:{instanceId[..8]})";
    }
}
