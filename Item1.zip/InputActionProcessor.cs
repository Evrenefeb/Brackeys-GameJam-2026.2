using UnityEngine;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// Unity Input System (yeni) veya Input (eski) ile ItemBehaviour arasındaki köprü.
    /// ActiveItem ayarlandığında ilgili input action'larını dinler ve
    /// ItemBehaviour üzerindeki doğru metodları çağırır.
    ///
    /// Bu örnek klasik Input.GetKey tabanlıdır; New Input System'a geçmek
    /// için sadece bu sınıfı değiştirmek yeterlidir.
    /// </summary>
    public class InputActionProcessor : MonoBehaviour
    {
        // ── Singleton (PlayerController üzerinde yaşar) ───────────
        private static InputActionProcessor _instance;
        public static InputActionProcessor Instance => _instance;

        // ── Aktif eşya ───────────────────────────────────────────
        private ItemBehaviour _activeBehaviour;
        private List<InputActionDefinition> _activeActions = new();

        // ── Hold durumu izleme ───────────────────────────────────
        private static readonly HashSet<string> _heldActions = new();
        private readonly Dictionary<string, bool> _lastHoldState = new();

        // ── Input mapping (actionId -> KeyCode) ──────────────────
        // TODO: Bunu bir configurable binding sistemiyle değiştirin
        private static readonly Dictionary<string, KeyCode> ActionKeyMap = new()
        {
            { "primary_fire",  KeyCode.Mouse0 },
            { "secondary_fire",KeyCode.Mouse1 },
            { "aim",           KeyCode.Mouse1 },
            { "skill_1",       KeyCode.Q      },
            { "skill_2",       KeyCode.E      },
            { "use",           KeyCode.Mouse1 },
            { "dig",           KeyCode.Mouse0 },
            { "eat",           KeyCode.Mouse1 },
        };

        // ─────────────────────────────────────────────────────────

        private void Awake()
        {
            _instance = this;
        }

        public void SetActiveItem(ItemBehaviour behaviour)
        {
            // Önceki eşyanın hold'larını temizle
            foreach (var actionId in _heldActions)
                Debug.Log($"[Input] Hold temizlendi: {actionId}");
            _heldActions.Clear();
            _lastHoldState.Clear();

            _activeBehaviour = behaviour;
            _activeActions   = behaviour != null
                ? new List<InputActionDefinition>(behaviour.Item.Definition.inputActions)
                : new List<InputActionDefinition>();
        }

        private void Update()
        {
            if (_activeBehaviour == null) return;

            // Tick (hold timer'lar ve held frame işlemleri)
            _activeBehaviour.Tick(Time.deltaTime);

            foreach (var action in _activeActions)
            {
                if (!ActionKeyMap.TryGetValue(action.actionId, out KeyCode key))
                {
                    Debug.LogWarning($"[Input] '{action.actionId}' için key mapping yok!");
                    continue;
                }

                switch (action.trigger)
                {
                    case InputTrigger.Tap:
                        if (Input.GetKeyDown(key))
                            _activeBehaviour.HandleTap(action);
                        break;

                    case InputTrigger.Hold:
                    {
                        bool isDown = Input.GetKey(key);
                        bool wasDown = _lastHoldState.TryGetValue(action.actionId, out bool prev) && prev;

                        if (isDown && !wasDown)
                            _activeBehaviour.HandleHoldStart(action);
                        else if (!isDown && wasDown)
                            _activeBehaviour.HandleHoldEnd(action);

                        _lastHoldState[action.actionId] = isDown;
                        break;
                    }

                    case InputTrigger.Held:
                    {
                        if (Input.GetKey(key))
                            _heldActions.Add(action.actionId);
                        else
                            _heldActions.Remove(action.actionId);
                        break;
                    }

                    case InputTrigger.Release:
                        if (Input.GetKeyUp(key))
                            _activeBehaviour.HandleRelease(action);
                        break;
                }
            }
        }

        /// <summary>Held trigger için her frame sorgulanır.</summary>
        public static bool IsActionHeld(string actionId) => _heldActions.Contains(actionId);
    }
}
