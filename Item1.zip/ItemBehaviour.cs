using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// Inventory'de aktif slotta bulunan eşyanın davranış bileşeni.
    /// Her eşya için bir alt sınıf yazılır; bu sınıf input yönetimini,
    /// hold-timer'ı ve ortak yaşam döngüsünü üstlenir.
    ///
    /// Alt sınıflar sadece On___() metodlarını override eder.
    /// </summary>
    [RequireComponent(typeof(AudioSource))]
    public abstract class ItemBehaviour : MonoBehaviour
    {
        // ── Referanslar ──────────────────────────────────────────
        protected ItemInstance Item { get; private set; }
        protected PlayerController Player { get; private set; }
        protected AudioSource AudioSrc { get; private set; }

        // ── Hold timer takibi ────────────────────────────────────
        private readonly Dictionary<string, float> _holdTimers = new();
        private readonly Dictionary<string, bool>  _holdFired  = new();

        // ─────────────────────────────────────────────────────────
        //  YAŞAM DÖNGÜSÜ
        // ─────────────────────────────────────────────────────────

        public void Initialize(ItemInstance item, PlayerController player)
        {
            Item   = item;
            Player = player;
            AudioSrc = GetComponent<AudioSource>();
            OnInitialized();
        }

        /// <summary>Eşya ele alındığında (equip).</summary>
        public void Equip()   { OnEquipped();   }

        /// <summary>Eşya bırakıldığında (unequip).</summary>
        public void Unequip() { OnUnequipped(); }

        protected virtual void OnInitialized() { }
        protected virtual void OnEquipped()    { }
        protected virtual void OnUnequipped()  { }

        // ─────────────────────────────────────────────────────────
        //  INPUT YÖNETİMİ — InputActionProcessor tarafından çağrılır
        // ─────────────────────────────────────────────────────────

        /// <summary>Her frame çağrılır; hold timer'ları burada ilerlenir.</summary>
        public void Tick(float dt)
        {
            foreach (var action in Item.Definition.inputActions)
            {
                if (action.trigger == InputTrigger.Hold)
                    TickHold(action, dt);
                else if (action.trigger == InputTrigger.Held)
                    TickHeld(action);
            }
            OnTick(dt);
        }

        protected virtual void OnTick(float dt) { }

        // ── Tap ──────────────────────────────────────────────────

        public void HandleTap(InputActionDefinition action)
        {
            DispatchAction(action.handlerMethodName);
        }

        // ── Hold (belirli süre tutunca tetikle) ──────────────────

        public void HandleHoldStart(InputActionDefinition action)
        {
            _holdTimers[action.actionId] = 0f;
            _holdFired[action.actionId]  = false;
            OnHoldStart(action.actionId);
        }

        public void HandleHoldEnd(InputActionDefinition action)
        {
            _holdTimers.Remove(action.actionId);
            _holdFired.Remove(action.actionId);
            OnHoldEnd(action.actionId);
        }

        private void TickHold(InputActionDefinition action, float dt)
        {
            if (!_holdTimers.ContainsKey(action.actionId)) return;
            if (_holdFired.TryGetValue(action.actionId, out bool fired) && fired) return;

            _holdTimers[action.actionId] += dt;
            if (_holdTimers[action.actionId] >= action.holdDuration)
            {
                _holdFired[action.actionId] = true;
                DispatchAction(action.handlerMethodName);
            }
        }

        // ── Held (basılı tutulduğu her frame) ────────────────────

        private void TickHeld(InputActionDefinition action)
        {
            // InputActionProcessor tarafından basılı tutuluyor mu kontrol edilir
            if (InputActionProcessor.IsActionHeld(action.actionId))
                DispatchAction(action.handlerMethodName);
        }

        protected virtual void OnHoldStart(string actionId) { }
        protected virtual void OnHoldEnd(string actionId)   { }

        // ── Release ──────────────────────────────────────────────

        public void HandleRelease(InputActionDefinition action)
        {
            DispatchAction(action.handlerMethodName);
        }

        // ─────────────────────────────────────────────────────────
        //  DISPATCH — method adını çağırır
        // ─────────────────────────────────────────────────────────

        private void DispatchAction(string methodName)
        {
            var method = GetType().GetMethod(methodName,
                System.Reflection.BindingFlags.Instance |
                System.Reflection.BindingFlags.Public   |
                System.Reflection.BindingFlags.NonPublic);

            if (method != null)
                method.Invoke(this, null);
            else
                Debug.LogWarning($"[ItemBehaviour] Method bulunamadı: '{methodName}' — {GetType().Name}");
        }

        // ─────────────────────────────────────────────────────────
        //  YARDIMCI METODLAR (alt sınıflar kullanır)
        // ─────────────────────────────────────────────────────────

        protected void PlaySound(AudioClip clip, float volume = 1f)
        {
            if (clip) AudioSrc.PlayOneShot(clip, volume);
        }

        protected void SpawnEffect(GameObject prefab, Vector3 position, Quaternion rotation)
        {
            if (prefab) Instantiate(prefab, position, rotation);
        }

        protected Coroutine StartItemCoroutine(IEnumerator routine)
            => StartCoroutine(routine);
    }
}
