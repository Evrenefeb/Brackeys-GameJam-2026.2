using UnityEngine;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// Her eşya için temel tanımlama ScriptableObject'i.
    /// Inspector'dan doldurulur, runtime'da değişmez.
    /// </summary>
    [CreateAssetMenu(fileName = "New Item", menuName = "Item System/Item Definition")]
    public class ItemDefinition : ScriptableObject
    {
        [Header("Temel Bilgiler")]
        public string itemId;           // Benzersiz ID, örn: "serenity_rifle"
        public string displayName;      // Görünen ad: "Serenity"
        [TextArea] public string description;
        public Sprite icon;
        public GameObject worldPrefab;  // Dünyada drop olduğunda görünen model

        [Header("Kategori")]
        public ItemCategory category;
        public ItemRarity rarity = ItemRarity.Common;

        [Header("Yığılabilirlik")]
        public bool isStackable = false;
        public int maxStack = 1;

        [Header("Input Binding'leri")]
        public List<InputActionDefinition> inputActions = new();

        [Header("Stat Modifiers (Pasif)")]
        public List<StatModifier> passiveModifiers = new();

        [Header("Ekstra Veriler (Weapon, Consumable vb.)")]
        public WeaponData weaponData;       // Silah ise doldurulur
        public ConsumableData consumableData; // Tüketilebilir ise doldurulur
        public ToolData toolData;            // Alet ise doldurulur

        /// <summary>
        /// Bu tanımdan bir runtime ItemInstance üretir.
        /// </summary>
        public ItemInstance CreateInstance(int amount = 1)
        {
            return new ItemInstance(this, Mathf.Clamp(amount, 1, maxStack));
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  ENUM'LAR
    // ─────────────────────────────────────────────────────────────

    public enum ItemCategory
    {
        Weapon,
        Tool,
        Consumable,
        Armor,
        Resource,
        Quest,
        Misc
    }

    public enum ItemRarity
    {
        Common,
        Uncommon,
        Rare,
        Epic,
        Legendary
    }

    // ─────────────────────────────────────────────────────────────
    //  INPUT ACTION TANIMI
    // ─────────────────────────────────────────────────────────────

    [System.Serializable]
    public class InputActionDefinition
    {
        public string actionId;              // "primary_fire", "aim", "skill_1", "skill_2"
        public string displayLabel;          // "Ateş Et", "Nişan Al"
        public InputTrigger trigger;         // Tap, Hold, Release, Held
        public float holdDuration = 0f;      // Hold için gereken süre (saniye)
        public string handlerMethodName;     // ItemBehaviour üzerindeki method adı
    }

    public enum InputTrigger
    {
        Tap,        // Tek basış
        Hold,       // holdDuration kadar basılı tut
        Release,    // Bırakınca
        Held        // Her frame basılıyken (örn: otomatik ateş)
    }

    // ─────────────────────────────────────────────────────────────
    //  STAT MODIFIER
    // ─────────────────────────────────────────────────────────────

    [System.Serializable]
    public class StatModifier
    {
        public string statName;          // "MoveSpeed", "MaxHealth" vb.
        public ModifierOperation op;
        public float value;
    }

    public enum ModifierOperation { Add, Multiply, Override }

    // ─────────────────────────────────────────────────────────────
    //  SİLAH VERİSİ
    // ─────────────────────────────────────────────────────────────

    [System.Serializable]
    public class WeaponData
    {
        [Header("Ateş")]
        public float fireRate = 1f;          // Saniyede kaç kez ateş
        public int magazineSize = 10;
        public float reloadTime = 2f;
        public float baseDamage = 25f;
        public float range = 100f;

        [Header("Mermi")]
        public GameObject bulletPrefab;
        public GameObject muzzleFlashPrefab;
        public AudioClip fireSound;
        public AudioClip reloadSound;
        public AudioClip emptySound;

        [Header("Nişan")]
        public float aimFOV = 40f;          // Nişan alınca FOV
        public float aimSensMultiplier = 0.5f;
    }

    // ─────────────────────────────────────────────────────────────
    //  TÜKETİLEBİLİR VERİSİ
    // ─────────────────────────────────────────────────────────────

    [System.Serializable]
    public class ConsumableData
    {
        public float useTime = 1f;           // Kullanım süresi (hold)
        public float healthRestore = 0f;
        public float staminaRestore = 0f;
        public float hungerRestore = 0f;
        public float thirstRestore = 0f;
        public AudioClip useSound;
        public GameObject useEffectPrefab;
    }

    // ─────────────────────────────────────────────────────────────
    //  ALET VERİSİ
    // ─────────────────────────────────────────────────────────────

    [System.Serializable]
    public class ToolData
    {
        public float useTime = 0.8f;
        public float harvestPower = 10f;
        public string targetTag;             // "Ore", "Tree" vb.
        public AudioClip useSound;
        public GameObject hitEffectPrefab;
    }
}
