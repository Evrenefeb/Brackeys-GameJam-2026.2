using UnityEngine;
using System.Collections;
using ItemSystem.Core;

namespace ItemSystem.Items
{
    /// <summary>
    /// METAL KAZMA
    ///
    /// LMB (Held) → Her use_time saniyede bir kazdır.
    ///              Hedefte "Ore" tag'i olan bir nesne varsa hasar uygular.
    ///
    /// InputActionDefinition'da:
    ///   actionId: "dig"  |  trigger: Held  |  handlerMethodName: "Dig"
    /// </summary>
    public class MetalPickaxeBehaviour : ItemBehaviour
    {
        private float _useCooldown = 0f;
        private bool  _isSwinging  = false;

        protected override void OnEquipped()
        {
            Debug.Log("[MetalKazma] Kazma hazır.");
        }

        protected override void OnTick(float dt)
        {
            if (_useCooldown > 0f) _useCooldown -= dt;
        }

        // ── Dig — trigger: Held ──────────────────────────────────
        /// actionId: dig
        private void Dig()
        {
            if (_useCooldown > 0f || _isSwinging) return;

            ToolData td = Item.Definition.toolData;
            _useCooldown = td.useTime;

            StartItemCoroutine(SwingRoutine(td));
        }

        private IEnumerator SwingRoutine(ToolData td)
        {
            _isSwinging = true;

            // TODO: Animasyon tetikle (swing)
            Debug.Log("[MetalKazma] 🔨 Swing başladı...");

            yield return new WaitForSeconds(td.useTime * 0.5f); // Vuruş ortasında hit check

            // Raycast ile hedefi bul
            if (Physics.Raycast(Player.PlayerCamera.transform.position,
                                Player.PlayerCamera.transform.forward,
                                out RaycastHit hit, 2.5f)) // 2.5m menzil
            {
                if (hit.collider.CompareTag(td.targetTag))
                {
                    Debug.Log($"[MetalKazma] ⛏ {hit.collider.name} kazıldı. Güç: {td.harvestPower}");
                    // TODO: hit.collider.GetComponent<IMineable>()?.ApplyHarvest(td.harvestPower);
                    PlaySound(td.useSound);
                    SpawnEffect(td.hitEffectPrefab, hit.point, Quaternion.LookRotation(hit.normal));
                }
                else
                {
                    Debug.Log($"[MetalKazma] Hedef maden değil: {hit.collider.name}");
                }
            }
            else
            {
                Debug.Log("[MetalKazma] Maden bulunamadı.");
            }

            yield return new WaitForSeconds(td.useTime * 0.5f);
            _isSwinging = false;
        }
    }
}
