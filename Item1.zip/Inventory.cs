using UnityEngine;
using System;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// Oyuncunun eşya çantası. Slot tabanlı, her slot bir ItemInstance tutabilir.
    /// Event sistemiyle UI senkronize edilir.
    /// </summary>
    public class Inventory : MonoBehaviour
    {
        [Header("Ayarlar")]
        [SerializeField] private int slotCount = 36;

        // ── Slotlar ──────────────────────────────────────────────
        private ItemInstance[] _slots;

        // ── Eventler ─────────────────────────────────────────────
        public event Action<int, ItemInstance> OnSlotChanged; // (slotIndex, newItem|null)
        public event Action<ItemInstance>      OnItemAdded;
        public event Action<ItemInstance>      OnItemRemoved;

        // ─────────────────────────────────────────────────────────

        private void Awake()
        {
            _slots = new ItemInstance[slotCount];
        }

        // ── Eşya Ekleme ──────────────────────────────────────────

        /// <summary>
        /// Envantere eşya ekler. Yığılabilirse dolu slotlara tamamlar,
        /// sonra boş slot arar. Başarı durumunda true döner.
        /// </summary>
        public bool TryAdd(ItemInstance item)
        {
            if (item == null || item.IsEmpty) return false;

            int remaining = item.Amount;

            // 1) Yığılabilirse mevcut yığınlara ekle
            if (item.Definition.isStackable)
            {
                for (int i = 0; i < _slots.Length && remaining > 0; i++)
                {
                    var slot = _slots[i];
                    if (slot == null || slot.Definition != item.Definition) continue;

                    int canFit = slot.Definition.maxStack - slot.Amount;
                    int add    = Mathf.Min(canFit, remaining);
                    slot.AddAmount(add);
                    remaining -= add;
                    OnSlotChanged?.Invoke(i, slot);
                }
            }

            // 2) Boş slot bul
            if (remaining > 0)
            {
                int emptySlot = FindEmptySlot();
                if (emptySlot < 0)
                {
                    Debug.Log($"[Inventory] Envanter dolu! {item.Definition.displayName} eklenemedi.");
                    return false;
                }

                var newItem = item.Clone(remaining);
                _slots[emptySlot] = newItem;
                OnSlotChanged?.Invoke(emptySlot, newItem);
                OnItemAdded?.Invoke(newItem);
            }

            return true;
        }

        // ── Eşya Çıkarma ─────────────────────────────────────────

        public bool TryRemove(int slotIndex, int amount = 1)
        {
            if (!IsValidSlot(slotIndex) || _slots[slotIndex] == null) return false;

            var item = _slots[slotIndex];
            item.AddAmount(-amount);

            if (item.IsEmpty)
            {
                OnItemRemoved?.Invoke(item);
                _slots[slotIndex] = null;
            }

            OnSlotChanged?.Invoke(slotIndex, _slots[slotIndex]);
            return true;
        }

        // ── Taşıma (Drag & Drop) ─────────────────────────────────

        public void SwapSlots(int fromIdx, int toIdx)
        {
            if (!IsValidSlot(fromIdx) || !IsValidSlot(toIdx)) return;

            (_slots[fromIdx], _slots[toIdx]) = (_slots[toIdx], _slots[fromIdx]);
            OnSlotChanged?.Invoke(fromIdx, _slots[fromIdx]);
            OnSlotChanged?.Invoke(toIdx,   _slots[toIdx]);
        }

        // ── Sorgular ─────────────────────────────────────────────

        public ItemInstance GetSlot(int index)
            => IsValidSlot(index) ? _slots[index] : null;

        public int Count(ItemDefinition def)
        {
            int total = 0;
            foreach (var slot in _slots)
                if (slot?.Definition == def) total += slot.Amount;
            return total;
        }

        public int FindEmptySlot()
        {
            for (int i = 0; i < _slots.Length; i++)
                if (_slots[i] == null) return i;
            return -1;
        }

        private bool IsValidSlot(int index) => index >= 0 && index < _slots.Length;

        public int SlotCount => slotCount;
    }
}
