using UnityEngine;

namespace ItemSystem.Core
{
    /// <summary>
    /// Stub — kendi PlayerController'ınızla değiştirin.
    /// ItemBehaviour'ın ihtiyaç duyduğu arayüzü sağlar.
    /// </summary>
    public class PlayerController : MonoBehaviour
    {
        // Kamera referansı (nişan, raycast için)
        public Camera PlayerCamera { get; private set; }

        // Stat erişimi (örn: WeaponBehaviour hasar için kullanabilir)
        public float GetStat(string statName) { Debug.Log($"[Player] GetStat: {statName}"); return 0f; }
        public void ApplyStat(string statName, float delta) { Debug.Log($"[Player] ApplyStat: {statName} += {delta}"); }

        // FOV kontrolü
        public void SetFOV(float fov) { Debug.Log($"[Player] SetFOV: {fov}"); }
        public void ResetFOV()        { Debug.Log("[Player] ResetFOV"); }

        // Hassasiyet çarpanı (nişan sırasında)
        public void SetSensMultiplier(float mult) { Debug.Log($"[Player] SensMultiplier: {mult}"); }

        private void Awake()
        {
            PlayerCamera = GetComponentInChildren<Camera>();
        }
    }
}
