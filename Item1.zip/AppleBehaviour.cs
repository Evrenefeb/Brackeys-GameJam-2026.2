using UnityEngine;
using System.Collections;
using ItemSystem.Core;

namespace ItemSystem.Items
{
    /// <summary>
    /// ELMA (Consumable)
    ///
    /// RMB (Hold, holdDuration: 1.5s) → Elmayı ye; hold süresince animasyon,
    ///                                   tamamlandığında sağlık/tokluk restore et.
    ///
    /// InputActionDefinition'da:
    ///   actionId: "eat"  |  trigger: Hold  |  holdDuration: 1.5  |  handlerMethodName: "Eat"
    /// </summary>
    public class AppleBehaviour : ItemBehaviour
    {
        private bool _isEating = false;

        protected override void OnEquipped()
        {
            Debug.Log("[Elma] Elma ele alındı.");
        }

        protected override void OnHoldEnd(string actionId)
        {
            if (actionId == "eat" && _isEating)
            {
                _isEating = false;
                StopAllCoroutines();
                Debug.Log("[Elma] Yeme iptal edildi.");
                // TODO: Animasyonu durdur
            }
        }

        // ── Eat — trigger: Hold 1.5s ─────────────────────────────
        /// actionId: eat
        private void Eat()
        {
            if (_isEating) return;
            StartItemCoroutine(EatRoutine());
        }

        private IEnumerator EatRoutine()
        {
            _isEating = true;
            ConsumableData cd = Item.Definition.consumableData;

            Debug.Log("[Elma] 🍎 Yeniliyor...");
            PlaySound(cd.useSound);

            // TODO: Yeme animasyonunu başlat

            yield return new WaitForSeconds(cd.useTime);

            if (!_isEating) yield break; // İptal edilmiş olabilir

            // Stat restore et
            if (cd.healthRestore  > 0f) Player.ApplyStat("Health",   cd.healthRestore);
            if (cd.hungerRestore  > 0f) Player.ApplyStat("Hunger",   cd.hungerRestore);
            if (cd.staminaRestore > 0f) Player.ApplyStat("Stamina",  cd.staminaRestore);
            if (cd.thirstRestore  > 0f) Player.ApplyStat("Thirst",   cd.thirstRestore);

            Debug.Log($"[Elma] ✅ Yendi! Sağlık +{cd.healthRestore}, Tokluk +{cd.hungerRestore}");

            SpawnEffect(cd.useEffectPrefab, Player.transform.position, Quaternion.identity);

            // Envanterden 1 adet çıkar
            // TODO: InventoryManager.Instance.ConsumeActiveItem();

            _isEating = false;
        }
    }
}
