using UnityEngine;
using System.Collections;
using ItemSystem.Core;

namespace ItemSystem.Items
{
    /// <summary>
    /// SERENITY — Keskin nişancı tüfeği
    ///
    /// LMB (Held)  → Ateş et (fire rate'e bağlı)
    /// RMB (Hold)  → Nişan al / bırak
    /// Q   (Hold 2s) → Patlayıcı mermi ateşle
    /// E   (Tap)   → Şarjördeki tüm mermileri boşalt, süper atış yap
    ///
    /// InputActionDefinition'lar ItemDefinition SO'da tanımlanır;
    /// bu sınıf sadece iş mantığını içerir.
    /// </summary>
    public class SerenityBehaviour : ItemBehaviour
    {
        // ── State ────────────────────────────────────────────────
        private float _fireCooldown   = 0f;
        private bool  _isAiming       = false;
        private bool  _isReloading    = false;
        private bool  _explosiveReady = false; // Skill 1 hold tamamlandı mı

        // ─────────────────────────────────────────────────────────

        protected override void OnEquipped()
        {
            Debug.Log("[Serenity] Donatıldı. Mermi: " + Item.CurrentAmmo + "/" + Item.Definition.weaponData.magazineSize);
        }

        protected override void OnUnequipped()
        {
            if (_isAiming) ExitAim();
        }

        protected override void OnTick(float dt)
        {
            if (_fireCooldown > 0f) _fireCooldown -= dt;
        }

        // ─────────────────────────────────────────────────────────
        //  HANDLER METODLARI — InputActionDefinition.handlerMethodName ile eşleşir
        // ─────────────────────────────────────────────────────────

        /// actionId: primary_fire  |  trigger: Held
        private void Fire()
        {
            if (_isReloading || _fireCooldown > 0f) return;

            if (!Item.HasAmmo)
            {
                TriggerReload();
                return;
            }

            WeaponData wd = Item.Definition.weaponData;
            float interval = 1f / wd.fireRate;
            _fireCooldown = interval;

            Item.SpendAmmo(1);

            // Raycast — düşmana çarptı mı?
            if (Physics.Raycast(Player.PlayerCamera.transform.position,
                                Player.PlayerCamera.transform.forward,
                                out RaycastHit hit, wd.range))
            {
                Debug.Log($"[Serenity] Hedef vuruldu: {hit.collider.name} — {wd.baseDamage} hasar");
                // TODO: hit.collider.GetComponent<IDamageable>()?.TakeDamage(wd.baseDamage);
            }
            else
            {
                Debug.Log("[Serenity] Kaçırıldı.");
            }

            PlaySound(wd.fireSound);
            SpawnEffect(wd.muzzleFlashPrefab, transform.position, transform.rotation);

            Debug.Log($"[Serenity] Ateş! Kalan mermi: {Item.CurrentAmmo}/{wd.magazineSize}");

            if (!Item.HasAmmo) TriggerReload();
        }

        /// actionId: aim  |  trigger: Hold (holdDuration: 0) — basınca gir, bırakınca çık
        private void EnterAim()
        {
            if (_isAiming) return;
            _isAiming = true;
            Player.SetFOV(Item.Definition.weaponData.aimFOV);
            Player.SetSensMultiplier(Item.Definition.weaponData.aimSensMultiplier);
            Debug.Log("[Serenity] Nişan alındı.");
        }

        protected override void OnHoldEnd(string actionId)
        {
            if (actionId == "aim") ExitAim();
            if (actionId == "skill_1" && !_explosiveReady)
            {
                Debug.Log("[Serenity] Skill 1 iptal edildi.");
                _explosiveReady = false;
            }
        }

        private void ExitAim()
        {
            _isAiming = false;
            Player.ResetFOV();
            Player.SetSensMultiplier(1f);
            Debug.Log("[Serenity] Nişan bırakıldı.");
        }

        // ─────────────────────────────────────────────────────────
        //  SKILL 1 — Hold 2 saniye → patlayıcı ateş
        // ─────────────────────────────────────────────────────────

        /// actionId: skill_1  |  trigger: Hold (holdDuration: 2)
        private void FireExplosive()
        {
            if (_isReloading || !Item.HasAmmo)
            {
                Debug.Log("[Serenity] Patlayıcı ateş için mermi yok!");
                return;
            }

            Item.SpendAmmo(1);
            _explosiveReady = false;

            WeaponData wd = Item.Definition.weaponData;

            Debug.Log("[Serenity] 💥 PATLAYICI ATEŞLENDİ!");

            if (Physics.Raycast(Player.PlayerCamera.transform.position,
                                Player.PlayerCamera.transform.forward,
                                out RaycastHit hit, wd.range))
            {
                Debug.Log($"[Serenity] Patlama merkezi: {hit.point}");
                // TODO: AoE hasar uygula Collider[] hits = Physics.OverlapSphere(hit.point, 5f);
                // TODO: SpawnEffect(explosionPrefab, hit.point, Quaternion.identity);
            }
        }

        // ─────────────────────────────────────────────────────────
        //  SKILL 2 — Tap → Tüm merimleri boşalt, süper atış
        // ─────────────────────────────────────────────────────────

        /// actionId: skill_2  |  trigger: Tap
        private void PowerShot()
        {
            if (_isReloading) return;

            int ammoUsed = Item.CurrentAmmo;
            if (ammoUsed <= 0)
            {
                Debug.Log("[Serenity] Güçlü atış için mermi yok!");
                return;
            }

            Item.SpendAmmo(ammoUsed); // Tümünü harca

            float powerMultiplier = 1f + (ammoUsed * 0.5f);
            float damage = Item.Definition.weaponData.baseDamage * powerMultiplier;

            Debug.Log($"[Serenity] ⚡ GÜÇLÜ ATIŞ! {ammoUsed} mermi harcandı. Hasar: {damage:F0}");

            if (Physics.Raycast(Player.PlayerCamera.transform.position,
                                Player.PlayerCamera.transform.forward,
                                out RaycastHit hit, Item.Definition.weaponData.range * 1.5f))
            {
                Debug.Log($"[Serenity] Güçlü atış hedefi: {hit.collider.name} — {damage:F0} hasar");
                // TODO: hit.collider.GetComponent<IDamageable>()?.TakeDamage(damage);
                // TODO: Zıplama etkisi, ses, parçacık efekti
            }

            TriggerReload();
        }

        // ─────────────────────────────────────────────────────────
        //  RELOAD
        // ─────────────────────────────────────────────────────────

        private void TriggerReload()
        {
            if (_isReloading) return;
            StartItemCoroutine(ReloadRoutine());
        }

        private IEnumerator ReloadRoutine()
        {
            _isReloading = true;
            float reloadTime = Item.Definition.weaponData.reloadTime;
            Debug.Log($"[Serenity] Şarjör değiştiriliyor... ({reloadTime}s)");
            PlaySound(Item.Definition.weaponData.reloadSound);

            // TODO: Animasyon tetikle

            yield return new WaitForSeconds(reloadTime);

            Item.Reload();
            _isReloading = false;
            Debug.Log($"[Serenity] Şarjör dolu: {Item.CurrentAmmo}/{Item.Definition.weaponData.magazineSize}");
        }
    }
}
