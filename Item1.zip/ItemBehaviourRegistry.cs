using UnityEngine;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// itemId → ItemBehaviour prefab eşlemesi.
    /// EquipmentManager prefab'ı buradan bulur.
    /// Inspector'da doldurulur; yeni eşya eklendiğinde buraya kayıt eklenir.
    /// </summary>
    [CreateAssetMenu(fileName = "ItemBehaviourRegistry", menuName = "Item System/Behaviour Registry")]
    public class ItemBehaviourRegistrySO : ScriptableObject
    {
        [System.Serializable]
        public struct Entry
        {
            public string itemId;
            public GameObject behaviourPrefab;
        }

        public List<Entry> entries = new();

        private Dictionary<string, GameObject> _lookup;

        public void BuildLookup()
        {
            _lookup = new Dictionary<string, GameObject>(entries.Count);
            foreach (var e in entries)
            {
                if (string.IsNullOrEmpty(e.itemId) || e.behaviourPrefab == null) continue;
                _lookup[e.itemId] = e.behaviourPrefab;
            }
        }

        public GameObject GetPrefab(string itemId)
        {
            if (_lookup == null) BuildLookup();
            return _lookup.TryGetValue(itemId, out var prefab) ? prefab : null;
        }
    }

    /// <summary>
    /// Static erişim noktası — EquipmentManager bunu kullanır.
    /// Oyun başlangıcında Initialize() çağrılmalı.
    /// </summary>
    public static class ItemBehaviourRegistry
    {
        private static ItemBehaviourRegistrySO _registry;

        public static void Initialize(ItemBehaviourRegistrySO registry)
        {
            _registry = registry;
            _registry.BuildLookup();
            Debug.Log("[Registry] ItemBehaviourRegistry hazır.");
        }

        public static GameObject GetPrefab(string itemId)
        {
            if (_registry == null)
            {
                Debug.LogError("[Registry] Registry Initialize edilmemiş!");
                return null;
            }
            return _registry.GetPrefab(itemId);
        }
    }
}
