using UnityEngine;
using System;
using System.Collections.Generic;

namespace ItemSystem.Core
{
    /// <summary>
    /// Hotbar ve ekipman yönetimi.
    /// Aktif slotu değiştirdiğinde doğru ItemBehaviour'ı spawn eder.
    /// </summary>
    public class EquipmentManager : MonoBehaviour
    {
        [Header("Referanslar")]
        [SerializeField] private Inventory inventory;
        [SerializeField] private InputActionProcessor inputProcessor;
        [SerializeField] private Transform itemHoldPoint;   // Kamera/el altındaki transform

        [Header("Hotbar")]
        [SerializeField] private int hotbarSize = 8;
        [SerializeField] private int[] hotbarSlotIndices;   // Inventory slot → hotbar pozisyonu

        // ── State ────────────────────────────────────────────────
        private int _activeHotbarIndex = 0;
        private ItemBehaviour _activeBehaviour;
        private readonly Dictionary<string, GameObject> _behaviourPrefabs = new();

        // ── Eventler ─────────────────────────────────────────────
        public event Action<int, ItemInstance> OnHotbarSelectionChanged;

        // ─────────────────────────────────────────────────────────

        private void Awake()
        {
            if (hotbarSlotIndices == null || hotbarSlotIndices.Length != hotbarSize)
            {
                hotbarSlotIndices = new int[hotbarSize];
                for (int i = 0; i < hotbarSize; i++) hotbarSlotIndices[i] = i;
            }
        }

        private void Update()
        {
            // Scroll wheel ile hotbar değiştir
            float scroll = Input.GetAxisRaw("Mouse ScrollWheel");
            if (scroll > 0f)  SelectHotbarSlot((_activeHotbarIndex - 1 + hotbarSize) % hotbarSize);
            if (scroll < 0f)  SelectHotbarSlot((_activeHotbarIndex + 1) % hotbarSize);

            // 1-8 tuşları
            for (int i = 0; i < Mathf.Min(hotbarSize, 8); i++)
                if (Input.GetKeyDown(KeyCode.Alpha1 + i))
                    SelectHotbarSlot(i);
        }

        public void SelectHotbarSlot(int hotbarIndex)
        {
            if (hotbarIndex < 0 || hotbarIndex >= hotbarSize) return;
            _activeHotbarIndex = hotbarIndex;

            int invSlot = hotbarSlotIndices[hotbarIndex];
            ItemInstance item = inventory.GetSlot(invSlot);

            EquipItem(item);
            OnHotbarSelectionChanged?.Invoke(hotbarIndex, item);
        }

        // ── Ekipman ──────────────────────────────────────────────

        private void EquipItem(ItemInstance item)
        {
            // Önceki eşyayı unequip et
            if (_activeBehaviour != null)
            {
                _activeBehaviour.Unequip();
                Destroy(_activeBehaviour.gameObject);
                _activeBehaviour = null;
            }

            inputProcessor.SetActiveItem(null);

            if (item == null) return;

            // ItemBehaviour prefab'ını bul ve spawn et
            GameObject behaviourPrefab = ItemBehaviourRegistry.GetPrefab(item.Definition.itemId);
            if (behaviourPrefab == null)
            {
                Debug.LogWarning($"[Equipment] '{item.Definition.itemId}' için behaviour prefab bulunamadı.");
                return;
            }

            GameObject behaviourGo = Instantiate(behaviourPrefab, itemHoldPoint);
            behaviourGo.transform.localPosition = Vector3.zero;
            behaviourGo.transform.localRotation = Quaternion.identity;

            _activeBehaviour = behaviourGo.GetComponent<ItemBehaviour>();
            if (_activeBehaviour == null)
            {
                Debug.LogError($"[Equipment] Prefab'da ItemBehaviour component'i yok: {item.Definition.displayName}");
                return;
            }

            PlayerController player = GetComponent<PlayerController>();
            _activeBehaviour.Initialize(item, player);
            _activeBehaviour.Equip();
            inputProcessor.SetActiveItem(_activeBehaviour);

            Debug.Log($"[Equipment] Donatıldı: {item.Definition.displayName}");
        }

        public ItemInstance GetActiveItem()
        {
            int invSlot = hotbarSlotIndices[_activeHotbarIndex];
            return inventory.GetSlot(invSlot);
        }
    }
}
