using UnityEngine;
using ItemSystem.Core;

namespace ItemSystem
{
    /// <summary>
    /// Oyun başlangıcında item sistemini başlatır.
    /// Sahnede tek bir GameObject'e eklenir.
    /// </summary>
    public class GameBootstrapper : MonoBehaviour
    {
        [Header("Item System")]
        [SerializeField] private ItemBehaviourRegistrySO behaviourRegistry;

        [Header("Test — Başlangıçta Envantere Ekle")]
        [SerializeField] private ItemDefinition[] startingItems;
        [SerializeField] private Inventory inventory;

        private void Awake()
        {
            // Registry'yi başlat
            ItemBehaviourRegistry.Initialize(behaviourRegistry);
        }

        private void Start()
        {
            // Test eşyalarını envantere ekle
            foreach (var def in startingItems)
            {
                if (def == null) continue;
                var instance = def.CreateInstance();
                bool added = inventory.TryAdd(instance);
                Debug.Log($"[Boot] Envantere eklendi: {def.displayName} — {added}");
            }
        }
    }
}
