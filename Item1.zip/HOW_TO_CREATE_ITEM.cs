// ══════════════════════════════════════════════════════════════
// DATA KLASÖRÜ — ItemDefinition ScriptableObject'leri burada yaşar
// ══════════════════════════════════════════════════════════════
//
// Yeni Eşya Oluşturma Adımları:
//
//  1. Project window'da sağ tıkla
//     → Item System → Item Definition
//     Dosyayı bu klasöre kaydet, örn: "Serenity.asset"
//
//  2. Inspector'ı doldur:
//     ├── itemId          : "serenity_rifle"   (benzersiz, kod tarafından kullanılır)
//     ├── displayName     : "Serenity"
//     ├── category        : Weapon
//     ├── rarity          : Legendary
//     ├── isStackable     : false
//     │
//     ├── Input Actions   (liste — her action bir satır)
//     │   ┌── [0] actionId: "primary_fire"
//     │   │       trigger : Held
//     │   │       handler : "Fire"
//     │   ├── [1] actionId: "aim"
//     │   │       trigger : Hold
//     │   │       holdDuration: 0
//     │   │       handler : "EnterAim"
//     │   ├── [2] actionId: "skill_1"
//     │   │       trigger : Hold
//     │   │       holdDuration: 2.0
//     │   │       handler : "FireExplosive"
//     │   └── [3] actionId: "skill_2"
//     │           trigger : Tap
//     │           handler : "PowerShot"
//     │
//     └── Weapon Data
//         ├── fireRate    : 0.8
//         ├── magazineSize: 5
//         ├── reloadTime  : 3.0
//         ├── baseDamage  : 120
//         └── range       : 300
//
//  3. Behaviour Prefab oluştur:
//     - Boş GameObject → "Serenity_Prefab"
//     - SerenityBehaviour.cs component'ini ekle
//     - Prefab olarak kaydet: Assets/ItemSystem/Prefabs/Serenity_Prefab.prefab
//
//  4. ItemBehaviourRegistry SO'ya kayıt ekle:
//     - "serenity_rifle" → Serenity_Prefab
//
//  Tamamdır! Eşya sisteme entegre edildi.
// ══════════════════════════════════════════════════════════════

// Bu dosya derlenmez; yalnızca dokümantasyon amaçlıdır.
